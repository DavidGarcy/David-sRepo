﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.CreditosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccesoAUnNuevoCreditoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EdicionDeUnCreditoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CancelacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ControlDePagosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultaDeSaldosAFavorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConsultaDeRestantesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerAprobadosYRechazadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.VerListaDeClientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerAdeudadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerCreditosPagadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreditosToolStripMenuItem, Me.ConsultaToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(903, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CreditosToolStripMenuItem
        '
        Me.CreditosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccesoAUnNuevoCreditoToolStripMenuItem, Me.EdicionDeUnCreditoToolStripMenuItem, Me.CancelacionesToolStripMenuItem, Me.ControlDePagosToolStripMenuItem})
        Me.CreditosToolStripMenuItem.Name = "CreditosToolStripMenuItem"
        Me.CreditosToolStripMenuItem.Size = New System.Drawing.Size(63, 20)
        Me.CreditosToolStripMenuItem.Text = "Creditos"
        '
        'AccesoAUnNuevoCreditoToolStripMenuItem
        '
        Me.AccesoAUnNuevoCreditoToolStripMenuItem.Name = "AccesoAUnNuevoCreditoToolStripMenuItem"
        Me.AccesoAUnNuevoCreditoToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.AccesoAUnNuevoCreditoToolStripMenuItem.Text = "Acceso a un Nuevo Credito"
        '
        'EdicionDeUnCreditoToolStripMenuItem
        '
        Me.EdicionDeUnCreditoToolStripMenuItem.Name = "EdicionDeUnCreditoToolStripMenuItem"
        Me.EdicionDeUnCreditoToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.EdicionDeUnCreditoToolStripMenuItem.Text = "Edicion de un Credito"
        '
        'CancelacionesToolStripMenuItem
        '
        Me.CancelacionesToolStripMenuItem.Name = "CancelacionesToolStripMenuItem"
        Me.CancelacionesToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.CancelacionesToolStripMenuItem.Text = "Cancelaciones"
        '
        'ControlDePagosToolStripMenuItem
        '
        Me.ControlDePagosToolStripMenuItem.Name = "ControlDePagosToolStripMenuItem"
        Me.ControlDePagosToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ControlDePagosToolStripMenuItem.Text = "Control de Pagos"
        '
        'ConsultaToolStripMenuItem
        '
        Me.ConsultaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConsultaDeSaldosAFavorToolStripMenuItem, Me.ConsultaDeRestantesToolStripMenuItem, Me.VerAprobadosYRechazadosToolStripMenuItem, Me.ToolStripMenuItem1, Me.VerListaDeClientesToolStripMenuItem, Me.VerAdeudadosToolStripMenuItem, Me.VerCreditosPagadosToolStripMenuItem})
        Me.ConsultaToolStripMenuItem.Name = "ConsultaToolStripMenuItem"
        Me.ConsultaToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.ConsultaToolStripMenuItem.Text = "Consulta"
        '
        'ConsultaDeSaldosAFavorToolStripMenuItem
        '
        Me.ConsultaDeSaldosAFavorToolStripMenuItem.Name = "ConsultaDeSaldosAFavorToolStripMenuItem"
        Me.ConsultaDeSaldosAFavorToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.ConsultaDeSaldosAFavorToolStripMenuItem.Text = "Consulta de Saldos a favor"
        '
        'ConsultaDeRestantesToolStripMenuItem
        '
        Me.ConsultaDeRestantesToolStripMenuItem.Name = "ConsultaDeRestantesToolStripMenuItem"
        Me.ConsultaDeRestantesToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.ConsultaDeRestantesToolStripMenuItem.Text = "Consulta de restantes"
        '
        'VerAprobadosYRechazadosToolStripMenuItem
        '
        Me.VerAprobadosYRechazadosToolStripMenuItem.Name = "VerAprobadosYRechazadosToolStripMenuItem"
        Me.VerAprobadosYRechazadosToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.VerAprobadosYRechazadosToolStripMenuItem.Text = "Ver Aprobados y Rechazados"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(223, 6)
        '
        'VerListaDeClientesToolStripMenuItem
        '
        Me.VerListaDeClientesToolStripMenuItem.Name = "VerListaDeClientesToolStripMenuItem"
        Me.VerListaDeClientesToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.VerListaDeClientesToolStripMenuItem.Text = "Ver Lista de Clientes"
        '
        'VerAdeudadosToolStripMenuItem
        '
        Me.VerAdeudadosToolStripMenuItem.Name = "VerAdeudadosToolStripMenuItem"
        Me.VerAdeudadosToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.VerAdeudadosToolStripMenuItem.Text = "Ver Adeudados"
        '
        'VerCreditosPagadosToolStripMenuItem
        '
        Me.VerCreditosPagadosToolStripMenuItem.Name = "VerCreditosPagadosToolStripMenuItem"
        Me.VerCreditosPagadosToolStripMenuItem.Size = New System.Drawing.Size(226, 22)
        Me.VerCreditosPagadosToolStripMenuItem.Text = "Ver Creditos Pagados"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(207, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Lista de Creditos Pendientes"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(9, 49)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(884, 393)
        Me.DataGridView1.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(10, 448)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(125, 47)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Acceso a un Nuevo Pago"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(141, 448)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(125, 47)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Acceso a un Nuevo Credito"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(766, 451)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(125, 47)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Salir"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(903, 507)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Pagina Principal - Modulo de Prestamos"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents CreditosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccesoAUnNuevoCreditoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EdicionDeUnCreditoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CancelacionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ControlDePagosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultaDeSaldosAFavorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultaDeRestantesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerAprobadosYRechazadosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents VerListaDeClientesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerAdeudadosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerCreditosPagadosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button

End Class
