﻿Imports System.Data.SqlClient
Class Form1
    Public oConexion As New SqlConnection
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        oConexion.ConnectionString = "server=INTERACTIVA-13; database=Prestamos1;integrated_security=true;"
        Try
            oConexion.Open()
            Dim oComando As New SqlCommand("select * from Client", oConexion)
            oComando.ExecuteNonQuery()
            Dim oAdaptador As New SqlDataAdapter(oComando)
            Dim oTabla As New DataTable
            oAdaptador.Fill(oTabla)
            DataGridView1.DataSource = oTabla
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ConsultaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultaToolStripMenuItem.Click

    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        oConexion.ConnectionString = "server=INTERACTIVA-13; database=Prestamos1;"
        Try
            oConexion.Open()
            Dim oComando As New SqlCommand("select * from Client", oConexion)
            oComando.ExecuteNonQuery()
            Dim oAdaptador As New SqlDataAdapter(oComando)
            Dim oTabla As New DataTable
            oAdaptador.Fill(oTabla)
            DataGridView1.DataSource = oTabla
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ModuloNPrestamo.Show()
    End Sub

    Private Sub CreditosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CreditosToolStripMenuItem.Click

    End Sub

    Private Sub AccesoAUnNuevoCreditoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccesoAUnNuevoCreditoToolStripMenuItem.Click
        ModuloNPrestamo.Show()
    End Sub
End Class
