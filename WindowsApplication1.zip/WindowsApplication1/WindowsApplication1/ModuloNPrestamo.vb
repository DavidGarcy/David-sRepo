﻿Imports System.Data.SqlClient

Public Class ModuloNPrestamo

    Private Sub ModuloNPrestamo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub TextBox1_TextChanged_1(sender As Object, e As EventArgs) Handles txtidclient.TextChanged

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim oQuery As New SqlCommand("select client_name, client_lastn, client_phone, client_email from Client where id_client = '" & txtidclient.Text.Trim() & "'", Form1.oConexion)
        oQuery.ExecuteNonQuery()
        Dim eReader As SqlDataReader = oQuery.ExecuteReader()
        While eReader.Read()
            lblClientName.Text = eReader("client_name").ToString() & eReader("client_lastn").ToString()
            lblClientPhone.Text = eReader("client_phone").ToString()
            lblClientMail.Text = eReader("client_mail").ToString()
        End While
    End Sub

    Private Sub Label2_Click_1(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub GroupBox1_Enter_1(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        txtidclient.ForeColor = Color.Red
        txtidcredit.ForeColor = Color.Red
        lblClientName.ForeColor = Color.LightGray
        lblClientPhone.ForeColor = Color.LightGray
        lblClientMail.ForeColor = Color.LightGray
        txtmontocredito.ForeColor = Color.Red
        txttasainteres.ForeColor = Color.Red
        comboplazo.ForeColor = Color.Red
        comboplazos.ForeColor = Color.Red
        MessageBox.Show("Desea Cancelar la Operacion de Nuevo Credito")
    End Sub
End Class